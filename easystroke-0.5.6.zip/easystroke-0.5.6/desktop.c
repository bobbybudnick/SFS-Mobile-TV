const char *desktop_file = "\
[Desktop Entry]\n\
Version=1.0\n\
Name=Easystroke Gesture Recognition\n\
Name[ca]=Reconeixement de gestos Easystroke\n\
Name[cs]=Easystroke rozeznávání gest\n\
Name[de]=Easystroke Gestenerkennung\n\
Name[el]=Easystroke Αναγνώρηση Χειρονομιών\n\
Name[es]=Reconocedor de gestos Easystroke\n\
Name[fi]=Easystroke hiirieleet\n\
Name[fr]=Reconnaissance gestuelle Easystroke\n\
Name[he]=זיהוי תנועות עכבר של Easystroke\n\
Name[hu]=Easystroke gesztusfelismerés\n\
Name[it]=Easystroke riconoscimento gesti\n\
Name[ja]=Easystroke ジェスチャ認識\n\
Name[ko]=이지스트로크 동작 인식\n\
Name[pl]=Easystroke Rozpoznawanie Gestów\n\
Name[ru]=Распознавание жестов мыши Easystroke\n\
Name[vi]=Trình nhận dạng hành vi Easystroke\n\
Name[zh_CN]=Easystroke 鼠标手势辨认\n\
Name[zh_TW]=Easystroke 滑鼠手勢辨識\n\
Type=Application\n\
Terminal=false\n\
Exec=%s\n\
Icon=easystroke\n\
Categories=GTK;Utility;Accessibility;\n\
Comment=Control your desktop using mouse gestures\n\
Comment[ca]=Controla el teu escriptori a través de gestos amb el ratolí\n\
Comment[cs]=Ovládejte počítač pomocí gest myši\n\
Comment[de]=Den Rechner mit Mausgesten bedienen\n\
Comment[el]=Ελέγξτε την επιφάνεια εργασίας χρησιμοποιώντας χειρονομίες ποντικιού\n\
Comment[es]=Controlar su escriotrio usando gestos de ratón\n\
Comment[fi]=Hallitse työpöytää hiirieleillä\n\
Comment[fr]=Contrôler votre bureau à l'aide de gestes de souris\n\
Comment[he]=ניתן לשלוט בשולחן העבודה באמצעות תנועות העכבר\n\
Comment[hu]=Az asztali környezet irányítása egérgesztusokkal\n\
Comment[it]=Controlla la scrivania utilizzando i gesti del muse\n\
Comment[ja]=マウス・ジェスチャを使用してデスクトップを制御します\n\
Comment[ko]=마우스 동작을 통해 데스크탑 제어\n\
Comment[pl]=Kontroluj pulpit używając gestów myszy\n\
Comment[ru]=Управление рабочим столом с помощью жестов мыши\n\
Comment[vi]=Điều khiển máy tính bằng những hành vi của chuột\n\
Comment[zh_CN]=通过鼠标手势控制你的桌面\n\
Comment[zh_TW]=使用滑鼠手勢控制您的桌面\n\
\n\
[Desktop Action About]\n\
Name=About\n\
Name[de]=Über\n\
Exec=%s about\n\
\n\
[Desktop Action Enable]\n\
Name=Enable/Disable\n\
Exec=%s enable\n\
\n\
[Desktop Action Quit]\n\
Name=Quit\n\
Name[de]=Schließen\n\
Exec=%s quit\n\
";
